import React from "react";
import Root from "./Root";
import Other from "./Other";
import TextField from "./TextField";
import Vendia from "./Vendia";


function App() {
  return (
    <>
    <Other />
    <Root />
    <Vendia />
    <TextField />
    </>
  );
}

export default App;
