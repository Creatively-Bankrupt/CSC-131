import { createVendiaClient } from "@vendia/client";
import { useState } from "react";

export default function Vendia(){
   const client = createVendiaClient({
      apiUrl: `https://525isitnw3.execute-api.us-west-2.amazonaws.com/graphql/`,
      websocketUrl: `wss://4tiko4jch8.execute-api.us-west-2.amazonaws.com/graphql`,
      apiKey: '6xZzW8nrMT4etYAHMDAM9upfm3AeYDqR4i7WBJrvnYT1'
    });
   const { entities } = client;
   console.log(entities);
   const [person, setPerson] = useState(" ");
   const [loading, setLoading] = useState(true); 

   async function listPerson(){
      const listPerson = await entities.person.list();
      setLoading(false)
      console.log(listPerson)
      setPerson(listPerson)
   }

   async function addPerson(){
      const productResponse = await entities.person.add({
         firstName: "user",
         lastName: "name",
         dl: "14651",
         dob: "123433",
         passportNumber: "615681",
         passportExpiration: "161301"
       });
      console.log(productResponse)
      }
   function handleSubmitList(event) {
      event.preventDefault();
      listPerson();
    }
   function handleSubmitAdd(event) {
      event.preventDefault();
      addPerson();
    }
   return(
      <div>
         <button onClick={handleSubmitList}>list</button>
         <button onClick={handleSubmitAdd}>add</button>
         { loading === false && 
         <div>
            {person.items[0].firstName}
         </div>
         }
      </div>
   )
}
